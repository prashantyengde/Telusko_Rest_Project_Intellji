package com.telusko.advice;

import com.telusko.controller.TouristController;
import com.telusko.exception.TouristNotFoundException;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;

//@RestControllerAdvice(basePackages = "com.telusko.controller")
public class TouristErrorController
{
//    @ExceptionHandler(TouristNotFoundException.class)
//    public ResponseEntity<ErrorDetails> handleTouristNotFoundException(TouristNotFoundException ex)
//    {
//        ErrorDetails details=new ErrorDetails();
//        details.setMessage(ex.getMessage());
//        details.setStatusCode(404);
//        details.setTimestamp(LocalDateTime.now());
//        return new ResponseEntity<ErrorDetails>(details, HttpStatus.BAD_REQUEST);
//    }
//    @ExceptionHandler(Exception.class)
//    public ResponseEntity<ErrorDetails> handleException(Exception ex)
//    {
//        ErrorDetails details=new ErrorDetails();
//        details.setMessage("Some Problem Occurred");
//        details.setStatusCode(404);
//        details.setTimestamp(LocalDateTime.now());
//        return new ResponseEntity<ErrorDetails>(details, HttpStatus.BAD_REQUEST);
//    }
//    @ExceptionHandler(Exception.class)
//    public ResponseEntity<ErrorDetails> handleException(Exception ex, HttpServletRequest request) throws Exception
//    {
//
//        String path = request.getRequestURI();
//
//        if (path.contains("/v3/api-docs") || path.contains("/swagger-ui"))
//        {
//            throw ex; // let Swagger handle it
//        }
//
//        return ResponseEntity.status(500).body(
//                new ErrorDetails("ERROR", ex.getMessage(), LocalDateTime.now())
//        );
//    }

}
