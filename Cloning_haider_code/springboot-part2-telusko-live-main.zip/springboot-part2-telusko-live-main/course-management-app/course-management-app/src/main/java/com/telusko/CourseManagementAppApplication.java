package com.telusko;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseManagementAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CourseManagementAppApplication.class, args);
	}

}
