package com.telusko.dto;

public class Tourist
{
    private Integer id;
    private String name;
    private String city;
    private String packageType;
    private Double budget;
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getPackageType() {
        return packageType;
    }
    public void setPackageType(String packageType) {
        this.packageType = packageType;
    }
    public Double getBudget() {
        return budget;
    }
    public void setBudget(Double budget) {
        this.budget = budget;
    }
    public Tourist(Integer id, String name, String city, String packageType, Double budget) {
        this.id=id;
        this.name = name;
        this.city = city;
        this.packageType = packageType;
        this.budget = budget;
    }
    public Tourist() {
    }
    public String toString() {
        return "Tourist [id=" + id + ", name=" + name + ", city=" + city + ", packageType=" + packageType
                + ", budget=" + budget + "]";
    }
}
