package com.telusko.BackendStudentapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendStudentappApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendStudentappApplication.class, args);
		

		//https://github.com/Gaurav560/student-management-system-frontend



		/*npm i

		npm install axios

		npm install react-router-dom

		npm run dev*/

	}

}
